<?php

namespace App;

use Exception;

class MyMerge
{
    protected $_inputFile;
    protected $_outputFile;
    

    public function __construct(string $inputFile, string $outputFile)
    {
        $this->_inputFile = $inputFile;
        $this->_outputFile = $outputFile;
    }


    /**
     * Parses the provided csv input file and merges
     * the info with the data from the API call
     * generating a new csv file with the provided
     * csv output file name
     * @return void
     * @throws Exception
     */
    public function parseFile() :void
    {
        $myFile = $this->_inputFile;

        if (($file = fopen($this->_inputFile, "r")) !== FALSE) {

            $header_row = fgetcsv($file, 0, ",", "\"", "\"");
            file_put_contents($this->_outputFile,'Account ID,First Name,Created On,Status,Status Set On' . PHP_EOL);

            while (($data_row = fgetcsv($file, 0, ",", "\"", "\"")) !== FALSE) {

                $data = $this->grabApiInfo($data_row[0]);
                $data = json_decode($data, true);
                file_put_contents($this->_outputFile, "{$data_row[0]}, {$data_row[2]}, {$data_row[3]}, {$data['status']}, {$data['created_on']}" . PHP_EOL, FILE_APPEND );
            }

        }

        fclose($file);
    }


    /**
     * Fetch the Account info from the API
     * @param string $accID
     * @return string
     * @used-by parseFile()
     * @throws Exception
     */
    private function grabApiInfo(string $accID) :string
    {
        return file_get_contents("http://interview.wpengine.io/v1/accounts/{$accID}");
    }
}



if ( (isset($argv[1]) && isset($argv[2])) && (preg_match("/^.*\.(csv|CSV)$/", $argv[1]) === 1 && preg_match("/^.*\.(csv|CSV)$/", $argv[2]) === 1) ) {

    $input = trim($argv[1]);
    $output = trim($argv[2]);

    $res = new MyMerge($input, $output);

    try {

        $res->parseFile();

    } catch (Exception $e) {

        echo "There was an issue processing your request: {$e->getMessage()}";
    }

} else {

    echo "You must provide a CSV Input file AND a CSV Output filename like this: wpe_merge {Input file}.csv {Output file}.csv, please try again..!";
}
